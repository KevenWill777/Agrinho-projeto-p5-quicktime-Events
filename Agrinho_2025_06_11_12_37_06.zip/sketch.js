let qteKeys = ['A', 'S', 'D', "F"];
let currentKey = '';
let timeLimit = 0.95; // Tempo inicial para pressionar a tecla
let timer = 0;
let gameState = 'waiting';
let score = 0;

function setup() {
  createCanvas(600, 400);
  textSize(32);
  textAlign(CENTER, CENTER);
  nextQTE();
}

function draw() {
  background(220);

  if (gameState === 'waiting') {
    text("Pressione qualquer tecla para começar", width / 2, height / 2);
  } 
  else if (gameState === 'qte') {
    text("Pressione: " + currentKey, width / 2, height / 2 - 50);
    text("Tempo: " + nf(timeLimit - timer, 1, 2), width / 2, height / 2 + 50);

    if (timer > timeLimit) {
      gameOver(); // Fim de jogo se o tempo acabar
    }
    timer += deltaTime / 1000; // Atualiza o cronômetro
  } 
  else if (gameState === 'gameOver') {
    text("Game Over! Pontuação: " + score, width / 2, height / 2);
    text("Pressione qualquer tecla para reiniciar", width / 2, height / 2 + 50);
  }
}

function keyPressed() {
  if (gameState === 'waiting') {
    gameState = 'qte';
    score = 0;
    nextQTE();
    timer = 0;
    loop(); // Ativa o loop de animação
  } 
  else if (gameState === 'qte') {
    // Verifica se a tecla pressionada está correta
    if (key.toUpperCase() === currentKey) {
      score += 10;
      nextQTE();
      // Aumenta a dificuldade ao longo do tempo
      timeLimit = max(0.3, timeLimit * 0.95); // Diminui o tempo limite
    } else {
      gameOver();
    }
  }
  else if (gameState === 'gameOver') {
    gameState = 'waiting';
    timer = 0;
    score = 0;
    loop(); // Reinicia o loop do jogo
  }
}

function nextQTE() {
  currentKey = random(qteKeys); // Escolhe uma tecla aleatória
  timer = 0; // Zera o cronômetro
}

function gameOver() {
  gameState = 'gameOver';
  noLoop(); // Para o loop de animação
  background(255, 0, 0); // Exemplo de feedback visual: fundo vermelho
}
